"""Q4 - Elective set operations and membership/intersection experiments."""
import random, time
def main():
    ai={'192311001','192311004','192311007','192311009'}
    iot={'192311002','192311004','192311009','192311010'}
    all_students={f'1923110{i:02d}' for i in range(1,11)}
    both=ai & iot; exactly_one=ai ^ iot; neither=all_students - (ai | iot)
    print('Q4 ELECTIVE CLASHES')
    print('clash :',sorted(both)); print('exactly one:',sorted(exactly_one)); print('neither :',sorted(neither))
    # Method form: same results, written using set methods.
    both2=ai.intersection(iot); one2=ai.symmetric_difference(iot); neither2=all_students.difference(ai.union(iot))
    assert (both,exactly_one,neither)==(both2,one2,neither2)
    print('method_results_match:', True, 'empty:', set() & ai, 'identical clash:', ai & ai)
    random.seed(83); print('Membership seconds (list, set), target is last element:')
    for n in (10_000,100_000,1_000_000):
        values=list(range(n)); s=set(values); target=n-1
        t=time.perf_counter(); [target in values for _ in range(20)]; tl=time.perf_counter()-t
        t=time.perf_counter(); [target in s for _ in range(20)]; ts=time.perf_counter()-t
        print(f'  n={n}: list={tl:.6f}, set={ts:.6f}')
    a=set(range(0,800,2)); b=set(range(400,1200,2))
    t=time.perf_counter(); common=[x for x in a for y in b if x==y]; tn=time.perf_counter()-t
    t=time.perf_counter(); common2=a & b; to=time.perf_counter()-t
    assert set(common)==common2
    print(f'intersection 400x400 seconds nested={tn:.6f}, set_and={to:.6f}')
    try: { [1,2] }
    except TypeError as e: print('list-set-item error:',type(e).__name__)
    print('complexity: set membership/intersection O(1)/O(min(n,m)) average; nested comparison O(n*m)')

if __name__ == '__main__': main()
