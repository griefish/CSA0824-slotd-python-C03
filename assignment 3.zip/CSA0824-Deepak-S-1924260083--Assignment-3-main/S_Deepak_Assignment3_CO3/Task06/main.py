"""Q6 - Nested train timetable, station index and scaling experiment."""
import random, sys, time
DAYS=('Mon','Tue','Wed','Thu','Fri','Sat','Sun')
STATIONS=('Chennai','Tambaram','Villupuram','Trichy','Madurai','Salem','Erode','Coimbatore')
def build(n):
    trains={}
    for i in range(n):
        stops=[]; t=6*60+(i%120)
        for station in STATIONS[:5]:
            arr=f'{t//60:02d}:{t%60:02d}'; t+=4; dep=f'{t//60:02d}:{t%60:02d}'; t+=35
            stops.append((station,arr,dep))
        trains[f'{12600+i}']={'name':f'Express {i+1:05d}','stops':stops,'days':set(DAYS[:5]) if i%4 else set(DAYS)}
    return trains
def query_scan(trains, station, day):
    result=[]
    for no,info in trains.items():
        if day in info['days']:
            for stop in info['stops']:
                if stop[0]==station: result.append((no,info['name'],stop[2]))
    return sorted(result,key=lambda x:x[2])
def build_index(trains):
    idx={}
    for no,info in trains.items():
        for station,arr,dep in info['stops']: idx.setdefault(station,[]).append((no,arr,dep))
    return idx
def query_index(trains,idx,station,day):
    return sorted([(no,trains[no]['name'],dep) for no,arr,dep in idx.get(station,[]) if day in trains[no]['days']],key=lambda x:x[2])
def main():
    trains={'12601':{'name':'Kaveri Express','stops':[('Chennai','06:00','06:10'),('Tambaram','06:35','06:37'),('Villupuram','08:10','08:15')],'days':{'Mon','Tue','Wed','Thu','Fri'}},'12602':{'name':'Vaigai Express','stops':[('Chennai','12:00','12:15'),('Tambaram','12:40','12:42'),('Madurai','20:00','20:10')],'days':{'Mon','Wed','Fri'}},'12603':{'name':'Cheran Express','stops':[('Coimbatore','07:00','07:10'),('Erode','09:00','09:05'),('Chennai','14:00','14:10')],'days':{'Tue','Thu','Sat'}},'12604':{'name':'Pandian Express','stops':[('Chennai','20:00','20:10'),('Villupuram','22:00','22:05'),('Madurai','04:30','04:40')],'days':{'Mon','Tue','Wed','Thu','Fri','Sat'}},'12605':{'name':'Intercity','stops':[('Salem','08:00','08:05'),('Erode','09:15','09:20'),('Coimbatore','10:30','10:35')],'days':{'Mon','Tue','Wed','Thu','Fri'}}}
    print('Q6 RAILWAY TIMETABLE')
    station='Tambaram'; day='Mon'; rows=query_scan(trains,station,day)
    for r in rows: print(f'{r[0]} {r[1]} departs {station} {r[2]}')
    print('unknown_station:',query_scan(trains,'Atlantis',day),'non_running_day:',query_scan(trains,'Tambaram','Sun'))
    print('departure of third stop of 12601:',trains['12601']['stops'][2][2])
    print('Timing seconds per 100 repeated station queries (scan, indexed); trains=100/1k/10k:')
    for n in (100,1000,10000):
        data=build(n); idx=build_index(data); station='Chennai'; day='Mon'; expected=query_scan(data,station,day)
        t=time.perf_counter(); [query_scan(data,station,day) for _ in range(100)]; scan=time.perf_counter()-t
        t=time.perf_counter(); [query_index(data,idx,station,day) for _ in range(100)]; indexed=time.perf_counter()-t
        assert expected==query_index(data,idx,station,day)
        index_size=sys.getsizeof(idx)+sum(sys.getsizeof(v) for v in idx.values())
        print(f'  trains={n}: scan={scan:.6f}, index={indexed:.6f}; index_container_bytes={index_size}')
    print('complexity per query: scan O(total stops); indexed O(station candidates + matches log matches)')

if __name__ == '__main__': main()
