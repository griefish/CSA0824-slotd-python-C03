"""Q2 - Tuple keys, aliasing, copies, memory and completed grid code."""
import copy, sys, time

def main():
    rows, cols = 3, 4
    bad = [[0] * cols] * rows
    bad[0][1] = 7
    good = [[0 for _ in range(cols)] for _ in range(rows)]
    good[0][1] = 7
    print('Q2 TUPLES AND COPYING')
    print('bad :', bad); print('good:', good)
    print(bad[0] is bad[1], good[0] is good[1])
    stops = {(13.0827, 80.2707): 'Chennai Central', (13.0418, 80.2341): 'T. Nagar'}
    print(stops[(13.0418, 80.2341)])
    try: stops[[13.0418, 80.2341]] = 'invalid'
    except TypeError as e: print('list-key error:', type(e).__name__, str(e))
    nested=[[1],[2]]; alias=nested; shallow=copy.copy(nested); sliced=nested[:]; deep=copy.deepcopy(nested)
    nested[0].append(9)
    print('alias is nested:', alias is nested, 'shallow shares child:', shallow[0] is nested[0], 'deep shares child:', deep[0] is nested[0])
    print('nested tuple item mutation:', end=' '); record=("zone-A", [2,3]); record[1].append(4); print(record)
    big_list=list(range(1_000_000)); big_tuple=tuple(big_list)
    print(f'shallow_size_1M list={sys.getsizeof(big_list)} tuple={sys.getsizeof(big_tuple)} bytes (elements excluded)')
    t=time.perf_counter(); values=list(range(100_000)); list_create=time.perf_counter()-t
    t=time.perf_counter(); tup=tuple(range(100_000)); tuple_create=time.perf_counter()-t
    t=time.perf_counter(); a=sum(values[i] for i in range(1000)); list_idx=time.perf_counter()-t
    t=time.perf_counter(); b=sum(tup[i] for i in range(1000)); tuple_idx=time.perf_counter()-t
    assert a==b
    print(f'create_100k_seconds list={list_create:.6f} tuple={tuple_create:.6f}; index_1000_seconds list={list_idx:.6f} tuple={tuple_idx:.6f}')
    print('caller mutation: a function mutating a list argument changes the same referenced object')

if __name__ == '__main__': main()
