"""Q7 - Contact merging by normalized phone number and measured scaling."""
import random, re, time
def normalize_number(value):
    if not value: return ''
    digits=''.join(ch for ch in value if ch.isdigit())
    if digits.startswith('91') and len(digits)==12: digits=digits[2:]
    return digits
def normalize_name(value): return ' '.join((value or '').casefold().split())
def merge(contacts):
    merged={}
    for c in contacts:
        key=normalize_number(c.get('phone',''))
        if not key: continue
        item=merged.setdefault(key,{'names':set(),'numbers':set(),'emails':set()})
        if c.get('name','').strip(): item['names'].add(c['name'].strip())
        if c.get('phone','').strip(): item['numbers'].add(c['phone'].strip())
        if c.get('email','').strip(): item['emails'].add(c['email'].strip().casefold())
    return merged
def pairwise(contacts):
    groups=[]
    for c in contacts:
        key=normalize_number(c.get('phone',''))
        if not key: continue
        for g in groups:
            if g['key']==key:
                if c.get('name','').strip(): g['names'].add(c['name'].strip())
                if c.get('email','').strip(): g['emails'].add(c['email'].strip().casefold())
                g['numbers'].add(c['phone'].strip()); break
        else: groups.append({'key':key,'names':{c.get('name','')},'numbers':{c.get('phone','')},'emails':{c.get('email','').casefold()}})
    return groups
def main():
    contacts=[{'name':'Dr. Ravi','phone':'+91 98400 12345','email':'RAVI@example.com'},{'name':'ravi kumar','phone':'9840012345','email':'ravi.alt@example.com'},{'name':'Maya','phone':'+91-90000-00001','email':'maya@example.com'},{'name':'Maya','phone':'+91-90000-00002','email':'maya2@example.com'},{'phone':'9000000001','email':''},{'name':'No phone','phone':'','email':'none@example.com'}]
    print('Q7 CONTACT MERGING')
    merged=merge(contacts)
    for key,value in sorted(merged.items()): print(key, {k:sorted(v) for k,v in value.items()})
    assert len(merged)==3 and len(merged['9840012345']['emails'])==2
    print('same-name rule: records merge only by normalized phone, so equal names with different numbers remain distinct')
    print('missing phone policy: skip because no reliable identity key is available')
    random.seed(83); print('Timing seconds (dictionary merge, pairwise at 1k; 100k pairwise estimate):')
    base=[]
    for i in range(100_000):
        person=i//2; phone=f'+91 90000 {person:05d}'
        base.append({'name':f'Person {person}','phone':phone if i%2==0 else phone.replace(' ',''),'email':f'p{person}@example.com' if i%2==0 else ''})
    for n in (1000,100000):
        data=base[:n]
        t=time.perf_counter(); result=merge(data); fast=time.perf_counter()-t
        detail=f'groups={len(result)}'
        if n==1000:
            t=time.perf_counter(); slow=pairwise(data); quadratic=time.perf_counter()-t
            assert len(slow)==len(result); detail+=f' pairwise={quadratic:.6f}'
        else: detail+=f' pairwise_estimate_from_1k~{(quadratic*(n/1000)**2):.1f}s (quadratic extrapolation, not run)'
        print(f'  contacts={n}: dict={fast:.6f}; {detail}')
    print('complexity: dictionary O(n) average time and O(u) space; pairwise O(n^2) comparisons')

if __name__ == '__main__': main()
