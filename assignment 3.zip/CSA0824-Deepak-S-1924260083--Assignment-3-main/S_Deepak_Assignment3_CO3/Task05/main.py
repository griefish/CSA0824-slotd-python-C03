"""Q5 - Sensor cleaning via loops, comprehension, map/filter, and memory."""
import random, sys, time
def valid(c): return -50 <= c <= 50
def loop_convert(xs):
    out=[]
    for c in xs:
        if valid(c): out.append((c,c*9/5+32))
    return out
def comp_convert(xs): return [(c,c*9/5+32) for c in xs if valid(c)]
def map_filter_convert(xs): return list(map(lambda c:(c,c*9/5+32),filter(lambda c:-50<=c<=50,xs)))
def main():
    readings=[-55,-2,4,9,52,7]
    print('Q5 SENSOR CLEANING')
    print('loop:',loop_convert(readings)); print('comprehension:',comp_convert(readings)); print('map_filter:',map_filter_convert(readings))
    alarms=[(minute,c) for minute,c in enumerate(readings) if valid(c) and not 2<=c<=8]
    print('alarm_minutes (valid readings outside 2..8 C):', alarms)
    assert loop_convert(readings)==comp_convert(readings)==map_filter_convert(readings)
    print('all-valid parity:',len(loop_convert([4]*10))==len([4]*10),'all-invalid:',loop_convert([55,-51])==[])
    random.seed(83); print('Timing seconds (loop, comprehension, map/filter):')
    for n in (10_000,100_000,1_000_000):
        x=[random.uniform(-60,60) for _ in range(n)]; row=[]; expected=None
        for fn in (loop_convert,comp_convert,map_filter_convert):
            t=time.perf_counter(); r=fn(x); row.append(time.perf_counter()-t)
            if expected is None: expected=r
            else: assert r==expected
        print(f'  n={n}: loop={row[0]:.6f}, comprehension={row[1]:.6f}, map_filter={row[2]:.6f}; valid={len(expected)}')
    values=list(range(1000)); gen=(x*x for x in values)
    print(f'shallow_size_bytes list={sys.getsizeof(values)} generator={sys.getsizeof(gen)} (elements excluded)')
    print('complexity: all conversion methods O(n); list results O(n) space, generator O(1) iterator space')

if __name__ == '__main__': main()
