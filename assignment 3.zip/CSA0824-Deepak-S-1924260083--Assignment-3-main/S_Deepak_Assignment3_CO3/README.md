# CSA08 Assignment 3 CO3

**Student:** S Deepak  
**Register number:** 1924260083  
**Python:** 3.11.0  
**GitHub repository:** [PASTE WORKING LINK HERE]

## Contents and run commands

| Folder | Command | Result |
|---|---|---|
| Task01 | `python Task01/main.py` | Rainfall totals, moving averages, edge cases, and timing comparison. |
| Task02 | `python Task02/main.py` | Aliasing, grid correction, tuple keys, copies, memory, and timing. |
| Task03 | `python Task03/main.py` | Complaint frequencies, district/crop grouping, top words, edge cases, and timings. |
| Task04 | `python Task04/main.py` | Set reports, operator/method parity, membership and intersection timings. |
| Task05 | `python Task05/main.py` | Three sensor-cleaning methods, parity checks, timing and memory. |
| Task06 | `python Task06/main.py` | Timetable queries, station index, edge cases, and scaling timings. |
| Task07 | `python Task07/main.py` | Normalized contact merging and scaling timings. |

Each task folder contains the source, captured stdout (`output.txt`) and a rendered output image (`execution_output.png`). `benchmark_results.csv` collects the timing and memory output rows. The report is provided as editable DOCX and submission PDF. All programs are self-contained and use generated deterministic data; no external input files are required.

## Libraries

The task code uses only Python 3.11 standard-library modules. `requirements.txt` records Pillow, used only to render the evidence images.

## Results and measurement notes

Timing values were measured with Python 3.11.0 on the machine that generated the report and will vary across systems. Q7's 100,000-contact quadratic result is an explicitly labeled extrapolation from the measured 1,000-contact case; the quadratic run was not executed at 100,000 because it would require billions of comparisons. Container `getsizeof` measurements exclude the contained objects.

## Before submission

1. Replace `[PASTE WORKING LINK HERE]` in this README and on the PDF cover with the working repository URL.
2. Create `CSA08-1924260083-Assignment3` and make it public or add the course faculty as a collaborator.
3. Commit each task progressively, with at least one commit per task, so the history shows the work.
4. Upload the final PDF to both the SIMATS Online Programming Lab Portal and Google Classroom.
5. Review and understand each solution and measurement so you can explain it during verification.
