"""Q3 - Complaint word frequencies, grouping, and benchmark comparison."""
from collections import Counter
import random, re, time

STOP={'not','high','the','is','and','a','to','of'}
def tokens(text): return re.findall(r"[a-z0-9']+", text.lower())
def frequencies(texts, stop):
    counts={}
    for text in texts:
        for word in tokens(text):
            if word not in stop: counts[word]=counts.get(word,0)+1
    return counts
def top(counts,k): return sorted(counts.items(), key=lambda item:(-item[1],item[0]))[:k]
def main():
    calls=['seeds not received seeds delayed','fertiliser price high','seeds price high subsidy not received']
    print('Q3 COMPLAINT ANALYSIS')
    counts=frequencies(calls, {'not','high'}); print(top(counts,3))
    districts=[('North',calls[0]),('South',calls[1]),('North',calls[2])]
    grouped={};
    for district, complaint in districts: grouped.setdefault(district,[]).append(complaint)
    print('district_counts:', {k:len(v) for k,v in grouped.items()})
    crops=[('rice',calls[0]),('wheat',calls[1]),('rice',calls[2])]
    by_crop={}
    for crop, complaint in crops: by_crop.setdefault(crop,[]).append(complaint)
    print('complaints_by_crop:', {k:len(v) for k,v in by_crop.items()})
    print('edge_cases empty:', frequencies([''],STOP), 'case/punctuation:', frequencies(['SEEDS, seeds!'],STOP))
    random.seed(83); vocab=['seed','water','crop','loan','pest','price','soil','subsidy','rain','market']
    print('Timing seconds (dict, list.count, Counter):')
    for n in (1000,10000,100000):
        texts=[' '.join(random.choices(vocab,k=7)) for _ in range(n)]
        words=[w for s in texts for w in tokens(s)]; unique=set(words)
        t=time.perf_counter(); d={}
        for w in words: d[w]=d.get(w,0)+1
        td=time.perf_counter()-t
        t=time.perf_counter(); lc={w:words.count(w) for w in unique}; tl=time.perf_counter()-t
        t=time.perf_counter(); c=Counter(words); tc=time.perf_counter()-t
        assert d==lc==c
        print(f'  complaints={n}: dict={td:.6f}, list.count={tl:.6f}, Counter={tc:.6f}; words={len(words)} distinct={len(unique)}')
    print('price precedes received because equal counts are sorted alphabetically')
    print('complexity: dictionary/Counter O(n) average time, O(d) space; repeated list.count O(n*d)')

if __name__ == '__main__': main()
