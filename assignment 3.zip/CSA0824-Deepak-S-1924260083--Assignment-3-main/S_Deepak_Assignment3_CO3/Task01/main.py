"""Q1 - Rainfall lists, slices, moving averages and benchmarks."""
import random, time

def naive_average(values, window=7):
    return [sum(values[i:i+window]) / window for i in range(len(values)-window+1)]

def running_average(values, window=7):
    if len(values) < window: return []
    total = sum(values[:window]); out = [total/window]
    for i in range(window, len(values)):
        total += values[i] - values[i-window]
        out.append(total/window)
    return out

def main():
    random.seed(83)
    readings = [round(random.uniform(0, 35), 1) for _ in range(365)]
    weeks = [sum(readings[i:i+7]) for i in range(0, len(readings), 7)]
    print('Q1 RAINFALL ANALYSIS')
    print(f'days={len(readings)} weeks={len(weeks)} last_partial_week_days={len(readings)%7 or 7}')
    print(f'wettest_week={max(range(len(weeks)), key=weeks.__getitem__)+1} total={max(weeks):.1f} mm')
    print(f'driest_week={min(range(len(weeks)), key=weeks.__getitem__)+1} total={min(weeks):.1f} mm')
    print(f'7day_average_count={len(running_average(readings))}; dry_days={sum(v == 0 for v in readings)}')
    print(f'slices: [7:14]={readings[7:14]}; [-7:]={readings[-7:]}; [::7]={readings[::7][:5]}...')
    print(f'edge_cases empty={running_average([])} short={running_average([1,2,3])}')
    print('Timing seconds (naive, running-sum):')
    for n in (365, 36500, 365000):
        x = [random.random()*35 for _ in range(n)]
        row=[]
        for fn in (naive_average, running_average):
            t=time.perf_counter(); result=fn(x); row.append(time.perf_counter()-t)
        assert len(naive_average(x)) == len(running_average(x))
        print(f'  n={n}: {row[0]:.6f}, {row[1]:.6f} (windows={max(0,n-6)})')
    print('additions per full-window output: naive 7 sums; running sum 1 add + 1 subtract after initialization')
    print('complexity: naive O(7n)=O(n) for fixed window; running sum O(n); both output O(n) space')

if __name__ == '__main__': main()
